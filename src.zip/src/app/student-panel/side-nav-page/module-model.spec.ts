import { ModuleModel } from './module-model';

describe('ModuleModel', () => {
  it('should create an instance', () => {
    expect(new ModuleModel()).toBeTruthy();
  });
});
