import { Component, OnInit } from '@angular/core';
import { ModuleModel } from './module-model';
import { NavModuleServiceService } from './nav-module-service.service';

@Component({
  selector: 'app-side-nav-page',
  templateUrl: './side-nav-page.component.html',
  styleUrls: ['./side-nav-page.component.css']
})
export class SideNavPageComponent implements OnInit {
  moduleListObject = [];
  module_id: number;
  constructor(private navModuleSerObject: NavModuleServiceService) { }

  ngOnInit() {
    this.moduleListObject = this.navModuleSerObject.showAllModules();
  }

  // getQuesList(module_id: number)
  // {
  //   this.module_id = module_id;
  //   localStorage.setItem("mod_id",this.module_id.toString());
  // }
}
