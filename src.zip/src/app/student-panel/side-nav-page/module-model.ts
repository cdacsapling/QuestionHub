export class ModuleModel {
    moduleId: number;
    moduleName: string;

}
