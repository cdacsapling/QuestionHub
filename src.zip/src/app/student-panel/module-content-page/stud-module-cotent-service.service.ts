import { Injectable } from '@angular/core';

import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { QuestionModel } from './question-model';
@Injectable({
  providedIn: 'root'
})
export class StudModuleCotentServiceService {
 
  questionList = [
    {question_id:1, question_desc:"What is Java?"},
    {question_id:2, question_desc:"What is Operating System?"},
    {question_id:3, question_desc:"What is Exception Handling?"},
    {question_id:4, question_desc:"Differnce between final, finally and finalize?"},
    {question_id:5, question_desc:"What is Packeges?"}
  ];
  constructor(private httpclientObejct:HttpClient) { }

  getAllModuleList(): Observable<any>
  {
    let url = "http://localhost:8081/getModules";
    return this.httpclientObejct.get(url);
  }

  submitAnswer(qstn: QuestionModel):Observable<any> {
    let url = "http://localhost:8081/submitAnswer";
    return this.httpclientObejct.post(url,qstn);
  }

  getallQuestionListByModuleId()
  {
    return this.questionList;
  }



}