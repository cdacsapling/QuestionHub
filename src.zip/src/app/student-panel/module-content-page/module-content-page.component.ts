import { Component, OnInit } from '@angular/core';
import { StudModuleCotentServiceService } from './stud-module-cotent-service.service';
import { QuestionModel } from './question-model';

@Component({
  selector: 'app-module-content-page',
  templateUrl: './module-content-page.component.html',
  styleUrls: ['./module-content-page.component.css']
})
export class ModuleContentPageComponent implements OnInit {
  questionListObject = [];
  get_active_question_id: number;
  get_answer_desc: string;
 // module_id: number;
  constructor(private stdModuleServiceObejct: StudModuleCotentServiceService) {
    //this.module_id = parseInt(localStorage.getItem("mod_id"));
    //alert(this.module_id);
   }

  ngOnInit() {
    this.questionListObject = this.stdModuleServiceObejct.getallQuestionListByModuleId();
  }

  
  toggle(question_id:number)
  {
    //alert(question_id+" hello");
    this.get_active_question_id=question_id; 
  }

  submitAnswer()
  {
    //alert(this.get_answer_desc);
    let qstn: QuestionModel;
    qstn.qstn_id = this.get_active_question_id;
    qstn.qstn_ans = this.get_answer_desc;
    this.stdModuleServiceObejct.submitAnswer(qstn).subscribe(
      (data:any)=>{ 
        console.log("data got from server");
        //alert("data updated successfully");
         
        
       }    
    ,(error)=>{
      //will display error msgs accordingly
    });
  }

  getModuleList()
  {
    //alert("function is working");
   
    this.stdModuleServiceObejct.getAllModuleList().subscribe(
      (data:any)=>{ 
        console.log("data got from server");
        //alert("data updated successfully");
         
        
       }    
    ,(error)=>{
      //will display error msgs accordingly
    });
    
  }

}
