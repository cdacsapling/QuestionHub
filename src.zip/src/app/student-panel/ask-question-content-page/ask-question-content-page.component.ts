import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ask-question-content-page',
  templateUrl: './ask-question-content-page.component.html',
  styleUrls: ['./ask-question-content-page.component.css']
})
export class AskQuestionContentPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
