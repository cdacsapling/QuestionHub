import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-student-footer',
  templateUrl: './student-footer.component.html',
  styleUrls: ['./student-footer.component.css']
})
export class StudentFooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
