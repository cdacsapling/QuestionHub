import { StudentProfileModel } from './student-profile-model';

describe('StudentProfileModel', () => {
  it('should create an instance', () => {
    expect(new StudentProfileModel()).toBeTruthy();
  });
});
