import { TeacherProfileModel } from './teacher-profile-model';

describe('TeacherProfileModel', () => {
  it('should create an instance', () => {
    expect(new TeacherProfileModel()).toBeTruthy();
  });
});
