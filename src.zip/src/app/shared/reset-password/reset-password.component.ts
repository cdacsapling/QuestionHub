import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.css']
})
export class ResetPasswordComponent implements OnInit {
  newPassword: String;
  confirmPassword: String;

  constructor() { }

  ngOnInit() {
  }

  resetPassword()
  {
    if(this.newPassword == this.confirmPassword)
    {
      alert("success");
    }
    else
    {
      alert("fail");
    }
  }

}
