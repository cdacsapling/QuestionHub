
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginModel } from './login-model';
import { LoginServiceService } from './login-service.service';


@Component({
  selector: 'app-login-page',
  templateUrl: './login-page.component.html',
  styleUrls: ['./login-page.component.css']
})
export class LoginPageComponent implements OnInit {
   credential = new LoginModel();
  constructor(private loginSerObject:LoginServiceService,
    private route : Router,
    //private router:ActivateRoute
    ) { 
      this.credential.userRole ="student";
    }

  ngOnInit() {
  }
  logIn()
  {
    if(this.credential.userNumber != undefined && this.credential.userPassword != undefined)
    {
      
      localStorage.setItem("userNumber", this.credential.userNumber);
          if(this.credential.userRole == "student")
          {
            this.route.navigate(['/studentPage/'+this.credential.userNumber]);
          }
          else
          {
            this.route.navigate(['/teacherPanel/'+this.credential.userNumber]);
          }


     /*
      this.loginSerObject.validateUser(this.credential).subscribe(
        (data:LoginModel)=>{ 
          console.log(data.userNumber +"data got from server");
          localStorage.setItem("userNumber", this.credential.userNumber);
          this.credential.userRole = data.userRole;
          if(this.credential.userRole == "student")
          {
            this.route.navigate(['/studentPage/'+this.credential.userNumber]);
          }
          else
          {
            this.route.navigate(['/teacherPanel/'+this.credential.userNumber]);
          }
         }    
      ,(error)=>{
        //will display error msgs accordingly
      });
      */
    }
    
  }
}
