export class LoginModel {
    userNumber:string;
    userPassword:string;
    userRole : string;



}
