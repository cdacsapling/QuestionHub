package login;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import exam.hello.CredentialEntity;

@RestController
@CrossOrigin(origins = "*")
public class ControllerClassForCredential 
{
	private ServiceClassForCredential service_ref_obj;
	
	 public ControllerClassForCredential() {
		// TODO Auto-generated constructor stub
	}
	
	
	@Autowired
	public void setService_ref_obj(ServiceClassForCredential service_ref_obj) 
	{
		this.service_ref_obj = service_ref_obj;
	}





	@PostMapping("/updateCredential")
	public String updatePassword(@RequestBody CredentialEntity obj)//assume single select
	{
		//RestTemplate x=new RestTemplate();
		CredentialEntity returned_obj = service_ref_obj.updatePasswordForService(obj);
		if(returned_obj != null)
		{
			return "success";
		}
		else
		{
			return "fail";
		}
		
	}
	
	@PostMapping("/insertCredential")
	public String insert(@RequestBody CredentialEntity n)//assume single select
	{
		//RestTemplate x=new RestTemplate();
		
		CredentialEntity returned_obj =service_ref_obj.insertPasswordForService(n);
		if(returned_obj != null)
		{
			return "success";
		}
		else
		{
			return "fail";
		}
		
	}
	


}
