package login;

import org.springframework.beans.factory.annotation.Autowired;

import exam.hello.CredentialEntity;



public class ServiceClassForCredential 
{

	private RepoInteraceForCredential credential_repo_obj;
		
	@Autowired
	public void setCredential_repo_obj(RepoInteraceForCredential credential_repo_obj)
	{
		System.out.println("Service : repository DAO  wired to service ");
		this.credential_repo_obj = credential_repo_obj;
	}

	 public ServiceClassForCredential() 
	 {
		// TODO Auto-generated constructor stub
	}


	public CredentialEntity updatePasswordForService(CredentialEntity obj) {
		// TODO Auto-generated method stub
		if(credential_repo_obj.existsById(obj.getLogin_id()))
			credential_repo_obj.save(obj); //change of failing is almost zero.
		else
				System.out.println("update failed");
		return obj;
	}

	public CredentialEntity insertPasswordForService(CredentialEntity obj) {
		// TODO Auto-generated method stub
		if(!credential_repo_obj.existsById(obj.getLogin_id()))
			credential_repo_obj.save(obj); //change of failing is almost zero.
		else
				System.out.println("insert failed");
		return obj;
	}

}
