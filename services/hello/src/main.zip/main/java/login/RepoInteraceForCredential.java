package login;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import exam.hello.CredentialEntity;

@Repository
public interface RepoInteraceForCredential extends JpaRepository<CredentialEntity, Integer>
{

}
