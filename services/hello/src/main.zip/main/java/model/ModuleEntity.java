package model;

import java.util.Set;

import javax.persistence.*;

import exam.hello.QuestionEntity;

@Entity
@Table(name="module")
public class ModuleEntity {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="mod_id")
	private int module_id;
	
	@Column(name="mod_name")
	private String module_name;

	@OneToMany(mappedBy="module", cascade=CascadeType.ALL)
	private Set<QuestionEntity> question_obj;
	
	
	public int getModule_id() {
		return module_id;
	}

	public void setModule_id(int module_id) {
		this.module_id = module_id;
	}

	public String getModule_name() {
		return module_name;
	}

	public void setModule_name(String module_name) {
		this.module_name = module_name;
	}

	public ModuleEntity() {
		System.out.println("ctor of no argument for module entity");
		// TODO Auto-generated constructor stub
	}

	public Set<QuestionEntity> getQuestion_obj() {
		return question_obj;
	}

	public void setQuestion_obj(Set<QuestionEntity> question_obj) {
		this.question_obj = question_obj;
	}

	public ModuleEntity(int module_id, String module_name, Set<QuestionEntity> question_obj) {
		this.module_id = module_id;
		this.module_name = module_name;
		this.question_obj = question_obj;
	}
	
	
}
