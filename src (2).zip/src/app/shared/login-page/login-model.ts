export class LoginModel {
    userNumber:number;
    userPassword:string;
    userRole : string;



}
