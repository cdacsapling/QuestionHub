export class QuestionModel {
    qstn_id: number; 
    qstn_desc: string;
    qstn_ans: string;
}
