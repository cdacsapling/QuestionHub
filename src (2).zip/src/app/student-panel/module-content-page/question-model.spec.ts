import { QuestionModel } from './question-model';

describe('QuestionModel', () => {
  it('should create an instance', () => {
    expect(new QuestionModel()).toBeTruthy();
  });
});
