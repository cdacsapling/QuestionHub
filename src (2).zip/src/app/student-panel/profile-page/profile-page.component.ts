import { Component, OnInit } from '@angular/core';
import { StudentProfileModel } from './student-profile-model';
import { StudProfileServiceService } from './stud-profile-service.service';

@Component({
  selector: 'app-profile-page',
  templateUrl: './profile-page.component.html',
  styleUrls: ['./profile-page.component.css']
})
export class ProfilePageComponent implements OnInit {
  profileObject =  new StudentProfileModel();


  constructor(private profileServiceObejct: StudProfileServiceService) {
    
    //alert("sting is "+localStorage.getItem(JSON.parse(userLoginInfo)););
    this.profileObject.studentNumber = localStorage.getItem("userLogin");
    this.getStudentProfile();
   }

  ngOnInit() {
  }

  //get req
  getStudentProfile()
  {
    //alert("function is working");
   
    
    this.profileServiceObejct.getProfileStudent(this.profileObject.studentNumber).subscribe(
      (data:StudentProfileModel)=>{ 
        console.log(data.studentNumber +"data got from server");
        alert("data updated successfully");
         
        
       }    
    ,(error)=>{
      //will display error msgs accordingly
    });
    
  }


  //post req
  updateProf()
  {
    alert("function is working");
   
    this.profileServiceObejct.updateProfileStudent(this.profileObject).subscribe(
      (data:StudentProfileModel)=>{ 
        console.log(data.studentNumber +"data got from server");
        alert("data updated successfully");
         
        
       }    
    ,(error)=>{
      //will display error msgs accordingly
    });
    
  }

}
