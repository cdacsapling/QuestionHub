export class StudentProfileModel {
    studentNumber: string;
    studentPassword: String;
    studentName: String;
    studentEmail: String;
    studentMobileNumber: Number;
    StudentDept: String;


}
