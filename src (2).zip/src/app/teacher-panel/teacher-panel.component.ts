import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-teacher-panel',
  templateUrl: './teacher-panel.component.html',
  styleUrls: ['./teacher-panel.component.css']
})
export class TeacherPanelComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
