export class TeacherProfileModel {

    teacherNumber: string;
  teacherPassword: String;
  teacherName: String;
  teacherEmail: String;
  teacherMobileNumber: Number;
  teacherDept: String;
}
