import { Component, OnInit } from '@angular/core';
import { TeacherProfileServiceService } from './teacher-profile-service.service';
import { TeacherProfileModel } from './teacher-profile-model';

@Component({
  selector: 'app-profile-teacher-page',
  templateUrl: './profile-teacher-page.component.html',
  styleUrls: ['./profile-teacher-page.component.css']
})
export class ProfileTeacherPageComponent implements OnInit {
  profileObject = new TeacherProfileModel();

  


  constructor(private teacherProfSerObject: TeacherProfileServiceService) {
    alert("sting is "+localStorage.getItem("userNumber"));
    this.profileObject.teacherNumber = localStorage.getItem("userNumber");
    this.getTeacherProfile();
   
   }

  ngOnInit() {
  }


   //get req
   getTeacherProfile()
   {
     alert("function is working");
    /*
     this.teacherProfSerObject.getProfileTeacher(this.profileObject.teacherNumber).subscribe(
       (data:TeacherProfileModel)=>{ 
         console.log("data got from server");
         alert("data updated successfully");
         
        }    
     ,(error)=>{
       //will display error msgs accordingly
     });
     */
    }
 
   //post req
 
  updateTeacherProfile()
  {
    alert("function is working");
    this.teacherProfSerObject.updateProfTeacher(this.profileObject).subscribe(
      (data:any)=>{ 
        console.log("data got from server");
        alert("data updated successfully");
         
        
       }    
    ,(error)=>{
      //will display error msgs accordingly
    });
  }

}
